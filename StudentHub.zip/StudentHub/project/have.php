<!--================ Start CTA Area =================-->
	<div class="cta-area section_gap overlay">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-7">
					<h1>Have a new idea?</h1>
					<p>
					 you can post your ideas here and seek out for assistance by experts. 
					</p>
					<a href="postidea.php" class="primary_btn yellow_btn rounded">join with us</a>
				</div>
			</div>
		</div>
	</div>
	