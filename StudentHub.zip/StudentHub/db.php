<?php
session_start();
$server="localhost";
$username="root";
$password="root";
$db="codeathon";
$conn=mysqli_connect("$server","$username","$password","$db");
?>