
if(!empty($_REQUEST['eid']))
{
	$edid=$_REQUEST['eid'];
	$r=mysqli_query($conn,"select * from form where id='".edid."'") or die(mysqli_error($conn));
    while($re=mysqli_fetch_array($r))
	{
		$en=$_REQUEST['name'];
		$eb=$_REQUEST['branch'];
		$eg=$_REQUEST['gender'];
		$eop=$_REQUEST['opinion'];
	}
}
<td><a href="login.php?eid=<?php echo $res['id']; ?>">edit</a></td>
<th>Modify</th>
asdfghjkl;
<?php
$i=0;
$data=mysqli_query($conn,"select * from form") or die(mysqli_error($conn));
while($res=mysqli_fetch_array($data))
{
?> 
<tr>
<td><?php echo $i; ?></td>
<td><?php echo $res['name']; ?></td>
<td><?php echo $res['branch']; ?></td>
<td><?php echo $res['gender']; ?></td>
<td><?php echo $res['opinion']; ?></td>
<td><a href="login.php?id=<?php echo $res['id']; ?>">delete</a></td>
</tr>
<?php $i++;} ?>
</table>
<th>Delete</th>
if(!empty($_REQUEST['id']))
{
	$did=$_REQUEST['id'];
	$did=mysqli_query($conn,"delete from form where id='".$did."' ") or die(mysqli_error($conn));
	
}