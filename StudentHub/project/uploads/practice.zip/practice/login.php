<?php
$server="localhost";
$username="root";
$password="";
$db="nikhil";
$conn=mysqli_connect("$server","$username","$password","$db");
if($conn)
{
	echo "connected";
} 
if(isset($_POST['s']))
{
	$n=$_POST['t1'];
	$b=$_POST['t2'];
	$g=$_POST['t3'];
	$la=$_POST['l'];

	$lan = implode(",",$la);
		
	$img = $_FILES['file']['name'];
	
	if(!empty($img))
	{
		$target = "uploads/";
		$tfile = $target.basename($_FILES['file']['name']);
		if(move_uploaded_file($_FILES['file']['tmp_name'],$tfile))
		{
			echo "file uploaded";
		}
		
	}
	$op=$_POST['t4'];
	$sql=mysqli_query($conn,"insert into form(name,branch,gender,languages,opinion,img) values('$n','$b','$g','$lan','$op','$tfile')") or die(mysqli_error($conn));
	header("location:login.php");
}
if(!empty($_REQUEST['id']))
{
	$did=$_REQUEST['id'];
	$did=mysqli_query($conn,"delete from form where id='".$did."' ") or die(mysqli_error($conn));
	
}
if(!empty($_REQUEST['eid']))
{
	$edid=$_REQUEST['eid'];
	$edids=mysqli_query($conn,"select * from form where id='".$edid."'") or die(mysqli_error($conn));
    $ed_res=mysqli_fetch_array($edids);
}
if(isset($_POST['update']))
{ 
 $n=$_POST['t1'];
 $b=$_POST['t2'];
 $g=$_POST['t3'];
 $op=$_POST['t4'];
 $sql=mysqli_query($conn,"update form set name='".$n."',branch='".$b."',gender='".$g."',opinion='".$op."' where id='".$edid."'") or die(mysqli_error($conn));
 header("location:login.php");
	
}
?>
<html>
<head>login page</head>
<body>
<form name="f1" action="#" enctype="multipart/form-data" method="POST">
<table align="center" border="0" cellpadding="7">
<tr>
<td>name:</td>
<td><input type="text" name="t1" value="<?php if(!empty($_REQUEST['eid'])){ echo $ed_res['name'];}?>"></td>
</tr>
<tr>
<td>photo:</td>
<td><input type="file" name="file"></td>
</tr>
<tr>
<td>branch:</td>
<td>
<select name="t2">
<option >--select--</option>
<option value="it" <?php if(!empty($_REQUEST['eid'])){ if($ed_res['branch']=='it'){ echo "selected"; }} ?>>IT</option>
<option value="cse" <?php if(!empty($_REQUEST['eid'])){ if($ed_res['branch']=='cse'){ echo "selected"; }} ?>>CSE</option>
 <option value="ece" <?php if(!empty($_REQUEST['eid'])){ if($ed_res['branch']=='ece'){ echo "selected"; }} ?>>ECE</option>
<option value="eee" <?php if(!empty($_REQUEST['eid'])){ if($ed_res['branch']=='eee'){ echo "selected"; }} ?>>EEE</option>
<option value="civil" <?php if(!empty($_REQUEST['eid'])){ if($ed_res['branch']=='civil'){ echo "selected"; }} ?>>CIVIL</option>
<option value="mech" <?php if(!empty($_REQUEST['eid'])){ if($ed_res['branch']=='mech'){ echo "selected"; }} ?>>MECH</option>
</select>
</td>
</tr>
<tr>
<td>Gender:</td>
<td><input type="radio" value="male" name="t3" <?php if(!empty($_REQUEST['eid'])){ if($ed_res['gender']=='male'){ echo "checked"; } } ?>>Male<input type="radio" value="female" name="t3" <?php  if(!empty($_REQUEST['eid'])){ if($ed_res['gender']=='female'){ echo "checked"; } }?>>Female</td>
</tr>
<tr>
<td>Languages Known:</td>
<td>
<input type="checkbox" name="l[]" value="telugu">Telugu
<input type="checkbox" name="l[]" value="english">English
<input type="checkbox" name="l[]" value="hindhi">Hindhi
</td>
</tr>
<tr>
<td>opinion:</td>
<td><textarea name="t4"  value="<?php if(!empty($_REQUEST['eid'])){ echo $ed_res['opinion'];}?>"><?php if(!empty($_REQUEST['eid'])){ echo $ed_res['opinion'];}?></textarea></td>
</tr>
<?php
if(empty($_REQUEST['eid']))
{ ?>
<tr>
<td colspan="2" align="center"><input type="submit" value="submit" name="s"></td>
</tr>
<?php } else
{ ?>
<tr>
<td colspan="2" align="center"><input type="submit" value="update" name="update"></td>
<?php } ?>
</tr>
</table>
</form>
<table align="center" border="1" cellpadding="10">
<tr>
<th>s.no</th>
<th>name</th>
<th>photo</th>
<th>branch</th>
<th>gender</th>
<th>Languages Known</th>
<th>opinion</th>
<th>Delete</th>
<th>Modify</th>
</tr>
<?php
$i=0;
$data=mysqli_query($conn,"select * from form") or die(mysqli_error($conn));
while($res=mysqli_fetch_array($data))
{
?> 
<tr>
<td><?php echo $i; ?></td>
<td><?php echo $res['name']; ?></td>
<td><img src="<?php echo $res['img']; ?>" height="100" width="100"></td>
<td><?php echo $res['branch']; ?></td>
<td><?php echo $res['gender']; ?></td>
<td><?php echo $res['languages']; ?></td>
<td><?php echo $res['opinion']; ?></td>
<td><a href="login.php?id=<?php echo $res['id']; ?>">delete</a></td>
<td><a href="login.php?eid=<?php echo $res['id']; ?>">edit</a></td>
</tr>
<?php $i++;} ?>

</body>
</html>