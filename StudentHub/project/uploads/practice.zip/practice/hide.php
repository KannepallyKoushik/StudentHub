<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#button1").click(function(){
   $("p").hide(1000);
  });
  $("#button2").click(function(){ 
  $("p").show(3000);
  });
  $(".toggle").click(function(){
    $(".p1").toggle();
  });
  $(".p2").mouseenter(function(){
   alert("you have entered into p2");
  });
  $(".p3").mouseleave(function(){
   alert("you had left p2");
  });
  $(".button3").click(function(){
   $("#div1").fadeIn();
   $("#div2").fadeIn("slow");
   $("#div3").fadeIn("3000");
  });
  $(".button4").click(function(){
   $("#div1").fadeOut();
   $("#div2").fadeOut("slow");
   $("#div3").fadeOut("fast");
  });
  $("#button5").click(function(){
   $("#div1,#div2,#div3").fadeToggle();
  });
  $(".animate").click(function(){
   $("#div1,#div2,#div3").animate({
	 height: 'toggle'  
  });
  });
});
</script>
</head>
<body>
<p>Hiding the line using Jquery1.</p><button id="button1">hide</button><button id="button2">unhide</button>
<p class="p1">Hiding the line using Jquery1,toggle</p><button class="toggle">To hide and unhide the data</button>
<p class="p2">mouseenter function which shows an alert</p>
<p class="p3">mouseleave function which shows an alert</p>
<button class="button3">To fadeIn</button>
<div id="div1" style="height:80px;width:100px;display:none;background-color:red;"></div><br>
<div id="div2" style="height:80px;width:100px;display:none;background-color:yellow;"></div><br>
<div id="div3" style="height:80px;width:100px;display:none;background-color:blue;"></div><br>
<button class="button4">To fadeOut</button>
<button id="button5">To fadeIn and fadeOut</button>
<button class="animate">Animate</button>
</body>
</html>